' Abre o Lançar ClickUp BP-MS: se o serviço já estiver no ar, só abre o navegador;
' senão sobe o serviço local (escondido), que abre o navegador sozinho.
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
Set sh = CreateObject("WScript.Shell")
url = "http://127.0.0.1:8766/lancar.html"
noAr = False
On Error Resume Next
Set http = CreateObject("MSXML2.ServerXMLHTTP.6.0")
http.setTimeouts 1000, 1000, 1000, 1000
http.Open "GET", "http://127.0.0.1:8766/api/status", False
http.Send
If Err.Number = 0 Then noAr = (http.Status = 200)
If Err.Number <> 0 Then noAr = False
Err.Clear
On Error GoTo 0
If noAr Then
  sh.Run url, 1, False
Else
  sh.CurrentDirectory = fso.BuildPath(base, "central")
  sh.Run AcharPython(base) & " servico\servidor.py", 0, False
End If

' python.txt (gravado pelo instalador em UTF-16, aceita acento no caminho); se faltar, pyw
Function AcharPython(base)
  Dim f, arq, cam
  Set f = CreateObject("Scripting.FileSystemObject")
  arq = f.BuildPath(base, "python.txt")
  cam = ""
  If f.FileExists(arq) Then
    On Error Resume Next
    cam = Trim(f.OpenTextFile(arq, 1, False, -1).ReadLine)
    On Error GoTo 0
  End If
  If cam <> "" And f.FileExists(cam) Then
    AcharPython = """" & cam & """"
  Else
    AcharPython = "pyw"
  End If
End Function
