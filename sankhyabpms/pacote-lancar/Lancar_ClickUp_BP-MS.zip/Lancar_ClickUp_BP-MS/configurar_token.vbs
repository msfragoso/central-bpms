' Abre a janela do token do ClickUp com o Python gravado pelo instalador.
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
Set sh = CreateObject("WScript.Shell")
sh.CurrentDirectory = base
cam = ""
arq = fso.BuildPath(base, "python.txt")
If fso.FileExists(arq) Then
  On Error Resume Next
  cam = Trim(fso.OpenTextFile(arq, 1, False, -1).ReadLine)
  On Error GoTo 0
End If
If cam <> "" And fso.FileExists(cam) Then py = """" & cam & """" Else py = "pyw"
sh.Run py & " configurar_token.py", 1, False
