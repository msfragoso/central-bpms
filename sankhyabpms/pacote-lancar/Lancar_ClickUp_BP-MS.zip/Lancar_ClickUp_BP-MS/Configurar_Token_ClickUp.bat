@echo off
cd /d "%~dp0"
start "" wscript.exe "%~dp0configurar_token.vbs"
