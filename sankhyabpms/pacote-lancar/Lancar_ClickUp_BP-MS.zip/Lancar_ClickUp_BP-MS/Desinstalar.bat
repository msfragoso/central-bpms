@echo off
rem Remove o Lancar ClickUp BP-MS deste computador (o token fica no cofre do Windows).
copy /y "%~dp0desinstalar.ps1" "%TEMP%\desinstalar_lancar.ps1" >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\desinstalar_lancar.ps1"
