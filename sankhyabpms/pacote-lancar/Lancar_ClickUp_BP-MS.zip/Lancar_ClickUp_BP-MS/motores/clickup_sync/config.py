from credenciais import CLICKUP_TOKEN
CLICKUP_API = 'https://api.clickup.com/api/v2'
CLICKUP_HEADERS = {'Authorization': CLICKUP_TOKEN}
SPACE_ID_PMO_BP_MS = '90133723590'
PASTAS_IGNORADAS = {'1-BP-MS', '2- Horas Cruzadas', '3- Planos de Ação'}
FIELD_EXPERIENCE = '84181300-22c8-4a05-bc56-e236584fcb3b'
EXPERIENCE_OPTIONS = {'Não lançado': '665e39cf-381c-408b-8753-dcff7636fffd', 'Lançado': 'b4bd00b4-032d-4b2a-9501-762d6b930b8c', 'Alterar': 'dc7b474f-eb2b-4532-a45a-8ff1f1c06398', 'Lixeira': 'da6f4b56-c40b-411a-bd6d-6f6e09968e43'}
STATUS_NAO_EXECUTADO = 'não executado'
FIELD_ETAPA = '2bffbedf-89bd-4b12-ba60-dff41f8d3cff'
FIELD_USUARIO_CLIENTE = '773bc404-9cb0-4935-80e5-baadda33bf0b'
FIELD_PARCEIRO = 'd993c20b-a9b6-4fd4-bedc-c03b77e15ae5'
FIELD_MODULO = '81662e73-38c7-4600-98fa-941625125ee6'
ETAPA_ATENDIMENTO_AVULSO = '099676dd-040a-4c0c-aea8-4aacd238dfaf'
MODULO_ATENDIMENTO_AVULSO = 'b136ff65-14b6-476c-8d91-611f8b19e9b5'
