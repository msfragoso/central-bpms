import re
import unicodedata

def normalizar_texto(s):
    s = unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode('ascii')
    s = s.replace('.', '')
    s = re.sub('[^a-zA-Z0-9\\s]', ' ', s)
    s = re.sub('\\s+', ' ', s).strip().lower()
    return s

def distancia_edicao(a, b):
    if a == b:
        return 0
    la, lb = (len(a), len(b))
    d = [[0] * (lb + 1) for _ in range(la + 1)]
    for i in range(la + 1):
        d[i][0] = i
    for j in range(lb + 1):
        d[0][j] = j
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            custo = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + custo)
            if i > 1 and j > 1 and (a[i - 1] == b[j - 2]) and (a[i - 2] == b[j - 1]):
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[la][lb]

def palavras_parecidas(pt, pn):
    if pt == pn:
        return True
    if len(pt) >= 3 and len(pn) >= 3 and (pt in pn or pn in pt):
        return True
    tolerancia = 1 if max(len(pt), len(pn)) <= 5 else 2
    return distancia_edicao(pt, pn) <= tolerancia

def bate_aproximada(termo_norm, texto_norm):
    palavras_termo = termo_norm.split()
    palavras_texto = texto_norm.split()
    if not palavras_termo:
        return False
    for pt in palavras_termo:
        if not any((palavras_parecidas(pt, pn) for pn in palavras_texto)):
            return False
    return True
