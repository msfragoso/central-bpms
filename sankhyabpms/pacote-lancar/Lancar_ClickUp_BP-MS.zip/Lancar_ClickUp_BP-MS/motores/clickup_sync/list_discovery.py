import re
from .clickup_client import get_folders, get_lists_in_folder, get_folderless_lists
from .config import PASTAS_IGNORADAS
from .text_matching import normalizar_texto, bate_aproximada
FAP_REGEX = re.compile('\\b(\\d{4,6})\\b')

def _comeca_com_z(nome):
    return (nome or '').strip().upper().startswith('Z')

def _pasta_administrativa_ignorada(nome):
    return (nome or '').strip() in PASTAS_IGNORADAS

def extrair_fap_do_nome_lista(list_name):
    match = FAP_REGEX.search(list_name)
    return match.group(1) if match else None

def filtrar_listas_por_nome(listas, name_filter, avisar_fuzzy=False):
    if not name_filter:
        return listas
    if ',' in name_filter:
        termos = [t.strip() for t in name_filter.split(',') if t.strip()]
    else:
        termos = [name_filter]
    resultados_totais = []
    ids_vistos = set()
    for termo in termos:
        if termo.isdigit():
            exatas = [l for l in listas if termo in re.findall('\\d+', l['name'])]
            if not exatas:
                if avisar_fuzzy:
                    print(f"[Aviso] FAP '{termo}' não encontrada em nenhuma lista do ClickUp -- ignorada (número de FAP não usa correspondência aproximada). Confira o número digitado.")
                continue
            for l in exatas:
                if l['id'] not in ids_vistos:
                    ids_vistos.add(l['id'])
                    resultados_totais.append(l)
            continue
        termo_norm = normalizar_texto(termo)
        diretas = [l for l in listas if termo_norm in normalizar_texto(l['name'])]
        if diretas:
            for l in diretas:
                if l['id'] not in ids_vistos:
                    ids_vistos.add(l['id'])
                    resultados_totais.append(l)
            continue
        aproximadas = [l for l in listas if bate_aproximada(termo_norm, normalizar_texto(l['name']))]
        if not aproximadas:
            continue
        if avisar_fuzzy:
            print(f"[Aviso] Nenhuma lista com correspondência exata para '{termo}'. Usando correspondência aproximada:")
            for l in aproximadas:
                print(f"  ~ {l['folder_name'] or ''} / {l['name']}")
        for l in aproximadas:
            if l['id'] not in ids_vistos:
                ids_vistos.add(l['id'])
                resultados_totais.append(l)
    return resultados_totais

def get_all_lists_in_space(space_id, name_filter=None):
    listas = []
    for folder in get_folders(space_id):
        if _comeca_com_z(folder['name']) or _pasta_administrativa_ignorada(folder['name']):
            continue
        for lst in get_lists_in_folder(folder['id']):
            listas.append({'id': lst['id'], 'name': lst['name'], 'folder_name': folder['name']})
    for lst in get_folderless_lists(space_id):
        listas.append({'id': lst['id'], 'name': lst['name'], 'folder_name': None})
    listas = [l for l in listas if 'conclu' not in normalizar_texto(l['name'])]
    listas = [l for l in listas if not _comeca_com_z(l['name'])]
    if not name_filter:
        return listas
    return filtrar_listas_por_nome(listas, name_filter, avisar_fuzzy=True)
