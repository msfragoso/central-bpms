import concurrent.futures
import random
import time
from datetime import datetime
import requests
from .config import CLICKUP_API, CLICKUP_HEADERS, FIELD_EXPERIENCE, EXPERIENCE_OPTIONS, STATUS_NAO_EXECUTADO

def _data_para_ms(data_str, fim_do_dia=False):
    hora = '23:59:59' if fim_do_dia else '00:00:00'
    dt = datetime.strptime(f'{data_str} {hora}', '%Y-%m-%d %H:%M:%S')
    return int(dt.timestamp() * 1000)
_TIMEOUT_DURO_SEGUNDOS = 15
_executor_hard_timeout = concurrent.futures.ThreadPoolExecutor(max_workers=1, thread_name_prefix='clickup-timeout-duro')

def _executar_com_timeout_duro(fazer_requisicao, timeout=_TIMEOUT_DURO_SEGUNDOS):
    future = _executor_hard_timeout.submit(fazer_requisicao)
    return future.result(timeout=timeout)

def request_com_retry(fazer_requisicao, tentativas=5, espera_inicial=1.0):
    resp = None
    for tentativa in range(1, tentativas + 1):
        try:
            resp = _executar_com_timeout_duro(fazer_requisicao)
        except concurrent.futures.TimeoutError:
            print(f'  (ClickUp: tentativa {tentativa}/{tentativas} -- requisição travou além de {_TIMEOUT_DURO_SEGUNDOS}s sem resposta nem erro (provável trava de rede/proxy, não é erro da API)...)')
            if tentativa < tentativas:
                espera = espera_inicial * 2 ** (tentativa - 1) * random.uniform(0.7, 1.3)
                print(f'  aguardando {espera:.1f}s e tentando de novo...')
                time.sleep(espera)
                continue
            raise requests.exceptions.Timeout(f'Requisição travou além de {_TIMEOUT_DURO_SEGUNDOS}s em todas as {tentativas} tentativas (trava de rede/proxy -- a thread presa fica pra trás em segundo plano).')
        except requests.exceptions.RequestException as e:
            if tentativa < tentativas:
                espera = espera_inicial * 2 ** (tentativa - 1) * random.uniform(0.7, 1.3)
                print(f'  (ClickUp: tentativa {tentativa}/{tentativas} falhou -- {type(e).__name__}, aguardando {espera:.1f}s e tentando de novo...)')
                time.sleep(espera)
                continue
            raise
        if resp.status_code == 200 or (400 <= resp.status_code < 500 and resp.status_code != 429):
            if resp.status_code in (200, 201):
                remaining = resp.headers.get('X-RateLimit-Remaining')
                reset = resp.headers.get('X-RateLimit-Reset')
                if remaining is not None and int(remaining) <= 3 and (reset is not None):
                    espera_inteligente = max(0, float(reset) - time.time()) + 1.0
                    print(f'  [Rate Limit] Cota da API quase no fim (restam {remaining}). Pausando preventivamente {espera_inteligente:.1f}s...')
                    time.sleep(espera_inteligente)
            return resp
        if tentativa < tentativas:
            reset = resp.headers.get('X-RateLimit-Reset')
            if resp.status_code == 429 and reset is not None:
                espera = max(0, float(reset) - time.time()) + 1.5
                print(f'  (ClickUp: HTTP 429 Rate Limit atingido! Pausando exatos {espera:.1f}s ditados pelo servidor...)')
            else:
                espera = espera_inicial * 2 ** (tentativa - 1) * random.uniform(0.7, 1.3)
                print(f'  (ClickUp: tentativa {tentativa}/{tentativas} falhou -- HTTP {resp.status_code}, aguardando {espera:.1f}s e tentando de novo...)')
            time.sleep(espera)
    return resp

def get_tasks(list_id, include_closed=False, due_date_from=None, due_date_to=None):
    tasks = []
    page = 0
    while page < 50:
        params = {'page': page, 'include_closed': str(include_closed).lower(), 'subtasks': 'true'}
        if due_date_from:
            params['due_date_gt'] = _data_para_ms(due_date_from, fim_do_dia=False)
        if due_date_to:
            params['due_date_lt'] = _data_para_ms(due_date_to, fim_do_dia=True)
        resp = request_com_retry(lambda: requests.get(f'{CLICKUP_API}/list/{list_id}/task', headers=CLICKUP_HEADERS, params=params, timeout=20))
        if resp is None or resp.status_code != 200:
            status = resp.status_code if resp is not None else 'sem resposta'
            print(f'[ERRO GRAVE] Falha ao buscar tarefas da lista {list_id}... HTTP {status}')
            break
        data = resp.json()
        novas_tarefas = data.get('tasks', [])
        tasks.extend(novas_tarefas)
        if not novas_tarefas:
            break
        if data.get('last_page', True):
            break
        page += 1
        print(f'    (ClickUp: Lendo página {page + 1} de tarefas na lista...)')
    return tasks

def get_folders(space_id):
    resp = request_com_retry(lambda: requests.get(f'{CLICKUP_API}/space/{space_id}/folder', headers=CLICKUP_HEADERS, timeout=15))
    if resp is None or resp.status_code != 200:
        status = resp.status_code if resp is not None else 'sem resposta'
        texto = resp.text[:300] if resp is not None else ''
        print(f'[ERRO GRAVE] Falha ao buscar pastas do Space {space_id} mesmo após retries: {status} {texto} -- a lista de parceiros desta rodada pode estar incompleta.')
        return []
    return resp.json().get('folders', [])

def get_lists_in_folder(folder_id):
    resp = request_com_retry(lambda: requests.get(f'{CLICKUP_API}/folder/{folder_id}/list', headers=CLICKUP_HEADERS, timeout=15))
    if resp is None or resp.status_code != 200:
        status = resp.status_code if resp is not None else 'sem resposta'
        texto = resp.text[:300] if resp is not None else ''
        print(f'[ERRO GRAVE] Falha ao buscar listas da pasta {folder_id} mesmo após retries: {status} {texto} -- essa pasta pode ficar de fora desta rodada.')
        return []
    return resp.json().get('lists', [])

def get_folderless_lists(space_id):
    resp = request_com_retry(lambda: requests.get(f'{CLICKUP_API}/space/{space_id}/list', headers=CLICKUP_HEADERS, timeout=15))
    if resp is None or resp.status_code != 200:
        status = resp.status_code if resp is not None else 'sem resposta'
        texto = resp.text[:300] if resp is not None else ''
        print(f'[ERRO GRAVE] Falha ao buscar listas soltas do Space {space_id} mesmo após retries: {status} {texto} -- listas soltas podem ficar de fora desta rodada.')
        return []
    return resp.json().get('lists', [])

def get_field_value(task, field_id):
    for cf in task.get('custom_fields', []):
        if cf['id'] == field_id:
            return cf
    return None

def get_dropdown_selected_name(task, field_id):
    cf = get_field_value(task, field_id)
    if not cf or 'value' not in cf:
        return None
    idx = cf['value']
    options = cf.get('type_config', {}).get('options', [])
    for opt in options:
        if opt.get('orderindex') == idx:
            return opt['name']
    return None

def get_text_value(task, field_id):
    cf = get_field_value(task, field_id)
    if not cf:
        return None
    return cf.get('value')

def set_task_experience_status(task_id, status_name):
    option_id = EXPERIENCE_OPTIONS.get(status_name)
    if not option_id:
        raise ValueError(f'Status Experience desconhecido: {status_name}')
    body = {'value': option_id}
    resp = request_com_retry(lambda: requests.post(f'{CLICKUP_API}/task/{task_id}/field/{FIELD_EXPERIENCE}', headers=CLICKUP_HEADERS, json=body, timeout=15))
    sucesso = resp is not None and resp.status_code in (200, 201)
    if not sucesso:
        status = resp.status_code if resp is not None else 'sem resposta'
        texto = resp.text[:300] if resp is not None else ''
        print(f'  [AVISO] Falha ao atualizar campo Experience na tarefa {task_id} mesmo após retries: HTTP {status} -- {texto}')
    return sucesso

def limpar_data_vencimento(task_id):
    resp = request_com_retry(lambda: requests.put(f'{CLICKUP_API}/task/{task_id}', headers=CLICKUP_HEADERS, json={'due_date': None}, timeout=15))
    sucesso = resp is not None and resp.status_code in (200, 201)
    if not sucesso:
        status = resp.status_code if resp is not None else 'sem resposta'
        print(f'  [AVISO] Falha ao limpar a data de vencimento da tarefa {task_id}: HTTP {status}')
    return sucesso

def marcar_tarefa_como_nao_executada(task_id):
    body = {'status': STATUS_NAO_EXECUTADO, 'due_date': None}
    resp = request_com_retry(lambda: requests.put(f'{CLICKUP_API}/task/{task_id}', headers=CLICKUP_HEADERS, json=body, timeout=15))
    sucesso = resp is not None and resp.status_code in (200, 201)
    if not sucesso:
        status = resp.status_code if resp is not None else 'sem resposta'
        texto = resp.text[:300] if resp is not None else ''
        print(f"  [AVISO] Falha ao marcar tarefa {task_id} como '{STATUS_NAO_EXECUTADO}' / limpar data de vencimento mesmo após retries: HTTP {status} -- {texto}")
    return sucesso
