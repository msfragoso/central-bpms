import keyring
SERVICO = 'sankhya_experience_sync'
CLICKUP_TOKEN = keyring.get_password(SERVICO, 'CLICKUP_TOKEN')
EXPERIENCE_USER = keyring.get_password(SERVICO, 'EXPERIENCE_USER')
EXPERIENCE_PASS = keyring.get_password(SERVICO, 'EXPERIENCE_PASS')
if not CLICKUP_TOKEN:
    raise RuntimeError('Token do ClickUp não configurado. Rode Configurar_Token_ClickUp.bat.')
