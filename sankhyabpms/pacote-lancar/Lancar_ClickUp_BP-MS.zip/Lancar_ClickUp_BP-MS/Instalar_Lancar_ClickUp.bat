@echo off
rem Dê dois cliques aqui para instalar (ou atualizar) o Lançar ClickUp BP-MS.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0instalar.ps1"
