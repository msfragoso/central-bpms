/* Central BP-MS — componentes comuns de todas as telas HTML5 */
"use strict";

const BPMS = (() => {
  // Versão da Central (mesma do CHANGELOG.md e da tag vX.Y.Z no GitHub) -- atualizar a cada publicação.
  const VERSAO = "1.6.1";
  const TELAS = [
    { id: "lancar", href: "lancar.html", rotulo: "Lançar ClickUp" },
  ];

  // 04/11/2026 (Fragoso): ícone de cada módulo, usado no menu do topo e nos cartões do Início
  const ICONES = {
    lancar: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 8v8M8 12h8"/>',
    sync: '<path d="M21 12a9 9 0 0 1-15.5 6.2L3 16M3 12a9 9 0 0 1 15.5-6.2L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/>',
    conferencia: '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M9 13l2 2 4-4"/>',
    fase3: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    aceite: '<circle cx="12" cy="12" r="9"/><path d="M8 12l3 3 5-6"/>',
    agenda: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    atendimentos: '<path d="M21 11.5a8.5 8.5 0 0 1-12.6 7.4L3 21l2-5.2A8.5 8.5 0 1 1 21 11.5z"/>',
    permissoes: '<path d="M12 3l8 3v6c0 4.5-3.2 7.8-8 9-4.8-1.2-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
    backlog: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
    planilhas: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M3 15h18M10 4v16"/>',
    inicio: '<path d="M3 11l9-8 9 8"/><path d="M5 9.5V21h14V9.5M10 21v-6h4v6"/>',
  };
  const icone = (id) => `<svg class="ico" viewBox="0 0 24 24" aria-hidden="true">${ICONES[id] || ""}</svg>`;

  // ------------------------------------------------------------ util
  const $ = (sel, raiz = document) => raiz.querySelector(sel);
  const $$ = (sel, raiz = document) => Array.from(raiz.querySelectorAll(sel));
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const normalizar = (s) => String(s ?? "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().trim();
  const hojeBR = (dias = 0) => { const d = new Date(); d.setDate(d.getDate() + dias); return d.toLocaleDateString("pt-BR"); };

  function lerTema() { try { return localStorage.getItem("bpms-tema"); } catch (e) { return null; } }
  function gravarTema(t) { try { localStorage.setItem("bpms-tema", t); } catch (e) { /* sem storage */ } }
  const temaSalvo = lerTema();
  if (temaSalvo) document.documentElement.dataset.theme = temaSalvo;

  // ------------------------------------------------------------ API
  // Aberta pelo serviço (127.0.0.1:8766) usa o mesmo endereço; aberta pelo site
  // do GitHub fala com o serviço do PC pelo endereço local.
  const LOCAL = ["127.0.0.1", "localhost"].includes(location.hostname);
  const SERVICO = LOCAL ? "" : "http://127.0.0.1:8766";
  async function api(metodo, caminho, corpo) {
    const op = { method: metodo, headers: {} };
    if (corpo !== undefined) {
      op.headers["Content-Type"] = "application/json";
      op.headers["X-BPMS"] = "1";
      op.body = JSON.stringify(corpo);
    }
    let resp;
    try {
      resp = await fetch(SERVICO + caminho, op);
    } catch (e) {
      throw new Error("Serviço local fora do ar. Abra o atalho Central BP-MS (HTML5) na Área de Trabalho.");
    }
    let dados = {};
    try { dados = await resp.json(); } catch (e) { /* sem corpo */ }
    if (!resp.ok) {
      const erro = new Error(dados.erro || `Erro ${resp.status}`);
      erro.status = resp.status; erro.dados = dados;
      throw erro;
    }
    return dados;
  }
  const get = (c) => api("GET", c);
  const post = (c, corpo = {}) => api("POST", c, corpo);

  // ------------------------------------------------------------ atualização online
  // 04/11/2026 (Fragoso): ao abrir a tela, avisa se há versão nova no GitHub. Só atualiza com confirmação.
  async function verificarAtualizacao(topo) {
    let info;
    try { info = await get("/api/atualizacao/status"); } catch (e) { return; }
    if (!info.disponivel && !info.em_andamento) return;
    const barra = document.createElement("div");
    barra.className = "barra-atualizacao";
    barra.setAttribute("role", "status");
    topo.append(barra);   // dentro do cabeçalho fixo: fica visível mesmo com a tela rolada
    if (info.em_andamento) return aguardarAtualizacao(barra, info.versao_nova);
    barra.innerHTML = `<span>Nova versão disponível: <b>v${esc(info.versao_nova)}</b> (você está na v${esc(info.versao_local)}).</span>
      <button class="btn pequeno" type="button">Atualizar agora</button>`;
    $("button", barra).onclick = async () => {
      const ok = await confirmar(`Atualizar para a versão ${info.versao_nova}?`,
        `<p>O serviço vai reiniciar e as sessões abertas por ele serão fechadas. Talvez seja preciso fazer login de novo.</p><p>Suas configurações e dados não são alterados, e a versão atual fica guardada. Se a nova não abrir, ele volta sozinho para a atual.</p>${info.novidades ? `<p><b>Novidades</b></p><pre style="white-space:pre-wrap;max-height:220px;overflow:auto;font:inherit;margin:0">${esc(info.novidades)}</pre>` : ""}`,
        { botao: "Atualizar agora" });
      if (!ok) return;
      $("button", barra).disabled = true;
      try {
        await post("/api/atualizacao/aplicar", { confirmar: true });
        aguardarAtualizacao(barra, info.versao_nova);
      } catch (e) {
        $("button", barra).disabled = false;
        toast(e.message, "erro");
      }
    };
  }

  function aguardarAtualizacao(barra, versao) {
    barra.textContent = `Atualizando para a v${versao}. A página recarrega sozinha quando terminar…`;
    const limite = Date.now() + 120000;
    const conferir = async () => {
      try {
        const s = await get("/api/atualizacao/status");
        if (s.versao_local === versao && !s.em_andamento) return location.reload();
      } catch (e) { /* serviço reiniciando */ }
      if (Date.now() < limite) return void setTimeout(conferir, 2000);
      barra.textContent = `A atualização para a v${versao} não terminou. Recarregue a página e confira a versão no rodapé.`;
    };
    setTimeout(conferir, 3000);
  }

  // ------------------------------------------------------------ cabeçalho
  function montarTopo(ativo) {
    // Assinatura no rodapé de todas as telas (pedido do Fragoso, 21/10/2026).
    if (!document.querySelector(".assinatura")) {
      const rodape = document.createElement("footer");
      rodape.className = "assinatura";
      rodape.textContent = `by MarceloFragoso · v${VERSAO}`;
      rodape.style.cssText = "text-align:center;color:var(--suave);font-size:12px;padding:18px 0 22px;opacity:.85";
      document.body.append(rodape);
    }
    const topo = document.createElement("header");
    topo.className = "topo";
    topo.innerHTML = `<div class="topo-dentro">
      <a class="marca" href="index.html"><span class="selo">BP</span><span class="marca-texto">Central BP-MS</span></a>
      <button class="botao-menu" id="botao-menu" aria-expanded="false" aria-controls="nav-principal">☰ <span id="menu-atual"></span></button>
      <nav class="nav" id="nav-principal">${TELAS.map((t) => `<a href="${t.href}" class="${t.id === ativo ? "ativo" : ""}">${icone(t.id)}<span data-texto="nav.${t.id}">${t.rotulo}</span></a>`).join("")}</nav>
      <span class="pilula" id="pilula-servico">verificando…</span>
      <button class="botao-tema" id="botao-editar" title="Editar os textos desta tela">✎</button>
      <button class="botao-tema" id="botao-tema" title="Tema claro/escuro">◐</button>
    </div>`;
    document.body.prepend(topo);
    verificarAtualizacao(topo);
    $("#botao-editar").onclick = () => (document.body.classList.contains("editando") ? null : editarTextos());
    aplicarTextos().then(aplicarOrdemMenu).then(ajustarMenu);
    prepararMenu(topo);
    $("#botao-tema").onclick = () => {
      const escuro = document.documentElement.dataset.theme
        ? document.documentElement.dataset.theme === "dark"
        : matchMedia("(prefers-color-scheme: dark)").matches;
      const novo = escuro ? "light" : "dark";
      document.documentElement.dataset.theme = novo;
      gravarTema(novo);
    };
    const toasts = document.createElement("div");
    toasts.className = "toasts"; toasts.id = "toasts";
    document.body.append(toasts);
    atualizarPilula();
    setInterval(atualizarPilula, 5000);
  }

  // ------------------------------------------------------------ ordem dos módulos
  // 28/10/2026 (Fragoso): a ordem escolhida arrastando os cartões do Início vale também
  // para o menu do topo. Fica no serviço (dados/ordem_modulos.json); "Início" é sempre o 1º.
  let ordemSalva = null;
  async function lerOrdem() {
    if (ordemSalva) return ordemSalva;
    try { ordemSalva = (await get("/api/ordem")).ordem || []; } catch (e) { ordemSalva = []; }
    return ordemSalva;
  }
  function ordenarPor(ordem, itens, idDe) {
    const pos = new Map(ordem.map((id, i) => [id, i]));
    const chave = (x) => (pos.has(idDe(x)) ? pos.get(idDe(x)) : 1000 + itens.indexOf(x));
    return [...itens].sort((a, b) => chave(a) - chave(b));
  }
  async function aplicarOrdemMenu() {
    const nav = $("#nav-principal");
    const ordem = await lerOrdem();
    if (!nav || !ordem.length) return;
    const idDe = (a) => (TELAS.find((t) => t.href === a.getAttribute("href")) || {}).id;
    const links = $$("a", nav).filter((a) => idDe(a) !== "inicio");
    ordenarPor(ordem, links, idDe).forEach((a) => nav.append(a));
  }
  async function gravarOrdem(ordem) {
    ordemSalva = (await post("/api/ordem", { ordem })).ordem || ordem;
    await aplicarOrdemMenu();
    ajustarMenu();
  }

  // ------------------------------------------------------------ menu responsivo
  // O menu fica numa linha só; quando não cabe (tela estreita ou nomes
  // longos), vira o botão "☰ <tela atual>" com a lista aberta embaixo.
  function ajustarMenu() {
    const topo = $(".topo"), nav = $("#nav-principal");
    if (!topo || !nav) return;
    const ativo = $("a.ativo", nav);
    $("#menu-atual").textContent = ativo ? ativo.textContent : "Menu";
    if (topo.classList.contains("menu-aberto")) return;
    topo.classList.remove("menu-compacto");
    if (nav.scrollWidth > nav.clientWidth + 1) topo.classList.add("menu-compacto");
  }
  function prepararMenu(topo) {
    const botao = $("#botao-menu");
    const fechar = () => { topo.classList.remove("menu-aberto"); botao.setAttribute("aria-expanded", "false"); ajustarMenu(); };
    botao.onclick = (e) => {
      e.stopPropagation();
      const abrir = !topo.classList.contains("menu-aberto");
      topo.classList.toggle("menu-aberto", abrir);
      botao.setAttribute("aria-expanded", String(abrir));
      if (!abrir) ajustarMenu();
    };
    document.addEventListener("click", (e) => { if (topo.classList.contains("menu-aberto") && !e.target.closest("#nav-principal")) fechar(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && topo.classList.contains("menu-aberto")) fechar(); });
    if (window.ResizeObserver) new ResizeObserver(ajustarMenu).observe($(".topo-dentro", topo));
    else addEventListener("resize", ajustarMenu);
    document.fonts?.ready.then(ajustarMenu);
    ajustarMenu();
  }

  let ultimoStatus = null;
  async function atualizarPilula() {
    const p = $("#pilula-servico");
    try {
      const s = await get("/api/status");
      ultimoStatus = s;
      const ativas = s.ativas || (s.ativa ? [s.ativa] : []);
      if (ativas.length > 1) { p.className = "pilula rodando"; p.textContent = `${ativas.length} processos rodando: ${ativas.map((a) => a.titulo).join(" · ")}`; }
      else if (ativas.length) { p.className = "pilula rodando"; p.textContent = `rodando: ${ativas[0].titulo}`; }
      else if (!s.motores_encontrados) { p.className = "pilula erro"; p.textContent = "pasta dos motores não encontrada"; }
      else { p.className = "pilula ok"; p.textContent = "serviço local ok"; }
      p.title = p.textContent;  // em tela estreita a pílula vira só um ponto colorido
      $$("[data-ultimo-uso]").forEach((el) => {
        const v = s.ultimo_uso[el.dataset.ultimoUso];
        // 22/10/2026: também a data da última atualização do módulo.
        const at = (s.atualizado || {})[el.dataset.ultimoUso];
        el.textContent = [v && `último uso ${v}`, at && `atualizado em ${at.slice(0, 10)}`].filter(Boolean).join(" · ");
        if (at) el.title = `Módulo atualizado em ${at}`;
      });
      return s;
    } catch (e) {
      p.className = "pilula erro"; p.textContent = "serviço fora do ar"; p.title = p.textContent;
      return null;
    }
  }

  // ------------------------------------------------------------ textos editáveis
  // Elementos com data-texto="chave" (títulos, descrições, menu) podem ser
  // reescritos pelo botão ✎ do topo; o serviço guarda em dados/textos.json.
  let textosSalvos = {};
  function guardarPadroes() {
    $$("[data-texto]").forEach((el) => { if (el.dataset.padrao === undefined) el.dataset.padrao = el.textContent.trim(); });
  }
  async function aplicarTextos() {
    guardarPadroes();
    try { textosSalvos = (await get("/api/textos")).textos || {}; } catch (e) { return; }
    $$("[data-texto]").forEach((el) => {
      const v = textosSalvos[el.dataset.texto];
      el.textContent = v !== undefined ? v : el.dataset.padrao;
    });
  }

  function editarTextos() {
    guardarPadroes();
    const els = $$("[data-texto]");
    const antes = new Map(els.map((el) => [el, el.textContent]));
    document.body.classList.add("editando");
    els.forEach((el) => {
      el.contentEditable = "plaintext-only";
      if (el.contentEditable !== "plaintext-only") el.contentEditable = "true";
      el.spellcheck = true;
    });
    const evitarEnter = (e) => { if (e.key === "Enter" && e.target.closest?.("[data-texto]")) { e.preventDefault(); e.target.blur(); } };
    const evitarLink = (e) => { if (e.target.closest("[data-texto]")) e.preventDefault(); };
    document.addEventListener("keydown", evitarEnter, true);
    document.addEventListener("click", evitarLink, true);

    const barra = document.createElement("div");
    barra.className = "barra-edicao";
    barra.innerHTML = `<span>✎ Clique em qualquer título ou descrição marcado e escreva.</span>
      <button class="btn secundario pequeno" data-a="padrao">Restaurar padrão</button>
      <button class="btn secundario pequeno" data-a="cancelar">Cancelar</button>
      <button class="btn pequeno" data-a="salvar">Salvar textos</button>`;
    document.body.append(barra);

    function sair() {
      els.forEach((el) => el.removeAttribute("contenteditable"));
      document.body.classList.remove("editando");
      document.removeEventListener("keydown", evitarEnter, true);
      document.removeEventListener("click", evitarLink, true);
      barra.remove();
    }
    barra.onclick = async (e) => {
      const a = e.target.dataset.a;
      if (a === "cancelar") { antes.forEach((t, el) => { el.textContent = t; }); sair(); }
      else if (a === "padrao") {
        if (await confirmar("Restaurar textos padrão?", "Todos os textos editáveis desta tela voltam ao original.", { botao: "Restaurar" })) {
          els.forEach((el) => { el.textContent = el.dataset.padrao; });
        }
      } else if (a === "salvar") {
        const textos = {};
        els.forEach((el) => {
          const v = el.textContent.replace(/\s+/g, " ").trim();
          const chave = el.dataset.texto;
          if (!v || v === el.dataset.padrao) { if (chave in textosSalvos) textos[chave] = null; }
          else if (v !== textosSalvos[chave]) textos[chave] = v;
        });
        try {
          if (Object.keys(textos).length) textosSalvos = (await post("/api/textos", { textos })).textos;
          sair(); aplicarTextos().then(ajustarMenu);
          toast("Textos salvos.", "ok");
        } catch (err) { toast(err.message, "erro"); }
      }
    };
  }

  // ------------------------------------------------------------ toast / modal
  function toast(msg, tipo = "") {
    // mesma mensagem já na tela: não empilha outra igual
    if ([...$("#toasts").children].some((x) => x.textContent === msg)) return;
    const t = document.createElement("div");
    t.className = `toast ${tipo}`; t.textContent = msg;
    $("#toasts").append(t);
    setTimeout(() => t.remove(), tipo === "erro" ? 9000 : 5000);
  }

  /** opcoes: [{valor, rotulo, estilo: primario|perigo|neutro}] -> Promise(valor) */
  function modal({ titulo, texto = "", html = "", opcoes, perigo = false }) {
    return new Promise((resolver) => {
      const fundo = document.createElement("div");
      fundo.className = "fundo-modal";
      fundo.innerHTML = `<div class="modal ${perigo ? "perigo" : ""}" role="dialog" aria-modal="true">
        <h3>${esc(titulo)}</h3><div class="corpo">${html || esc(texto)}</div><div class="rodape"></div></div>`;
      const rodape = $(".rodape", fundo);
      opcoes.forEach((o, i) => {
        const b = document.createElement("button");
        b.className = "btn " + ({ perigo: "perigo", neutro: "secundario" }[o.estilo] || "");
        b.textContent = o.rotulo;
        b.onclick = () => { fundo.remove(); resolver(o.valor); };
        rodape.append(b);
        if (i === opcoes.length - 1) setTimeout(() => b.focus(), 30);
      });
      document.body.append(fundo);
    });
  }
  const confirmar = (titulo, html, { botao = "Confirmar", perigo = false } = {}) =>
    modal({ titulo, html, perigo, opcoes: [
      { valor: false, rotulo: "Cancelar", estilo: "neutro" },
      { valor: true, rotulo: botao, estilo: perigo ? "perigo" : "primario" },
    ] });
  const informar = (titulo, html) => modal({ titulo, html, opcoes: [{ valor: true, rotulo: "OK" }] });

  // ------------------------------------------------------------ tarefa (processo longo)
  /**
   * Acompanha uma tarefa do serviço: log ao vivo, perguntas, arquivos.
   * el: {log, status, statusTexto, arquivos}; aoTerminar(estadoFinal)
   */
  function acompanhar(tarefaId, el, aoTerminar) {
    let desde = 0, perguntaAberta = null, parado = false;
    if (el.log) el.log.textContent = "";
    el.status?.classList.add("ativo");
    if (el.arquivos) el.arquivos.innerHTML = "";
    async function ciclo() {
      if (parado) return;
      let t;
      try {
        t = await get(`/api/tarefas/${tarefaId}?desde=${desde}`);
      } catch (e) {
        if (el.statusTexto) el.statusTexto.textContent = e.message;
        setTimeout(ciclo, 2000);
        return;
      }
      if (t.linhas.length && el.log) {
        const perto = el.log.scrollHeight - el.log.scrollTop - el.log.clientHeight < 40;
        el.log.textContent += t.linhas.join("\n") + "\n";
        if (perto) el.log.scrollTop = el.log.scrollHeight;
      }
      desde = t.total_linhas;
      if (el.statusTexto) {
        el.statusTexto.textContent = { rodando: `${t.titulo} — rodando…`, aguardando: `${t.titulo} — aguardando sua resposta` }[t.estado] || t.mensagem;
      }
      if (t.pergunta && perguntaAberta !== t.pergunta.id) {
        perguntaAberta = t.pergunta.id;
        modal({ titulo: t.pergunta.titulo, texto: t.pergunta.texto, opcoes: t.pergunta.opcoes })
          .then((valor) => post(`/api/tarefas/${tarefaId}/responder`, { pergunta_id: t.pergunta.id, valor }))
          .catch((e) => toast(e.message, "erro"));
      }
      if (t.estado === "rodando" || t.estado === "aguardando") {
        setTimeout(ciclo, 700);
        return;
      }
      parado = true;
      el.status?.classList.remove("ativo");
      if (el.arquivos) mostrarArquivos(el.arquivos, t);
      atualizarPilula();
      toast(t.mensagem, t.estado === "concluida" ? "ok" : t.estado === "erro" ? "erro" : "");
      aoTerminar && aoTerminar(t);
    }
    ciclo();
    return { parar: () => { parado = true; } };
  }

  function mostrarArquivos(caixa, t) {
    caixa.innerHTML = t.arquivos.map((a) => {
      const base = `${SERVICO}/api/tarefas/${t.id}/arquivo/${a.indice}`;
      const html = /\.html?$/i.test(a.nome);
      return `<a class="btn secundario pequeno" href="${base}${html ? "?ver=1" : ""}" ${html ? 'target="_blank" rel="noopener"' : ""}>⬇ ${esc(a.rotulo)}</a>`;
    }).join("");
  }

  /** Se há tarefa destes tipos rodando (ex.: página recarregada), volta a acompanhá-la. */
  async function retomar(tipos, el, aoTerminar, aoRetomar) {
    const s = ultimoStatus || (await atualizarPilula());
    // v1.2.0: com vários processos rodando, retoma o desta tela (se houver).
    const t = s && (s.ativas || (s.ativa ? [s.ativa] : [])).slice().reverse().find((a) => tipos.includes(a.tipo));
    if (t) {
      aoRetomar && aoRetomar(t);
      return acompanhar(t.id, el, aoTerminar);
    }
    return null;
  }

  /** Inicia uma tarefa (POST) e acompanha; trata "já tem processo rodando". */
  async function iniciar(caminho, corpo, el, aoTerminar) {
    try {
      const r = await post(caminho, corpo);
      return acompanhar(r.tarefa, el, aoTerminar);
    } catch (e) {
      if (e.status === 409) {
        await informar("Processo em andamento", `${esc(e.message)}<br><br>Aguarde ele terminar (veja a pílula no topo).`);
      } else {
        toast(e.message, "erro");
      }
      aoTerminar && aoTerminar(null);
      return null;
    }
  }

  // ------------------------------------------------------------ campos
  function mascaraData(input) {
    input.placeholder = input.placeholder || "dd/mm/aaaa";
    input.inputMode = "numeric";
    input.maxLength = 10;
    input.addEventListener("input", () => {
      const d = input.value.replace(/\D/g, "").slice(0, 8);
      input.value = d.length > 4 ? `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}` : d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d;
    });
  }
  function dataValida(txt) {
    const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec((txt || "").trim());
    if (!m) return null;
    const d = new Date(+m[3], +m[2] - 1, +m[1]);
    return d.getDate() === +m[1] && d.getMonth() === +m[2] - 1 ? d : null;
  }

  /**
   * Busca com autocompletar, sem acento e sem maiúscula (como o CampoBusca da tela Tk).
   * Enter/Tab confirma o item marcado. onEscolher(valor).
   */
  function busca(input, opcoes, { onEscolher, livre = false } = {}) {
    const caixa = document.createElement("div");
    caixa.className = "busca";
    input.parentNode.insertBefore(caixa, input);
    caixa.append(input);
    input.autocomplete = "off";
    const lista = document.createElement("ul");
    lista.className = "busca-lista oculto";
    caixa.append(lista);
    let itens = opcoes.slice(), filtrados = [], marcado = 0;

    function desenhar() {
      const q = normalizar(input.value);
      filtrados = q ? itens.filter((o) => normalizar(o).includes(q)) : itens.slice();
      filtrados.sort((a, b) => (normalizar(b).startsWith(q) - normalizar(a).startsWith(q)));
      marcado = Math.min(marcado, Math.max(filtrados.length - 1, 0));
      lista.innerHTML = filtrados.length
        ? filtrados.slice(0, 80).map((o, i) => `<li data-i="${i}" class="${i === marcado ? "marcado" : ""}">${esc(o)}</li>`).join("")
        : `<li class="vazio">nenhuma opção</li>`;
      lista.classList.remove("oculto");
      lista.querySelector(".marcado")?.scrollIntoView({ block: "nearest" });
    }
    function fechar() { lista.classList.add("oculto"); }
    function escolher(v) {
      input.value = v; fechar();
      input.dispatchEvent(new Event("change"));
      onEscolher && onEscolher(v);
    }
    input.addEventListener("focus", desenhar);
    input.addEventListener("input", () => { marcado = 0; desenhar(); });
    input.addEventListener("blur", () => setTimeout(fechar, 150));
    input.addEventListener("keydown", (e) => {
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        if (lista.classList.contains("oculto")) return desenhar();
        marcado = (marcado + (e.key === "ArrowDown" ? 1 : -1) + filtrados.length) % Math.max(filtrados.length, 1);
        desenhar();
      } else if ((e.key === "Enter" || e.key === "Tab") && !lista.classList.contains("oculto") && filtrados.length && input.value) {
        if (e.key === "Enter") e.preventDefault();
        escolher(filtrados[marcado]);
      } else if (e.key === "Escape") fechar();
    });
    lista.addEventListener("mousedown", (e) => {
      const li = e.target.closest("li[data-i]");
      if (li) { e.preventDefault(); escolher(filtrados[+li.dataset.i]); }
    });
    return {
      valido: () => livre || itens.includes(input.value),
      definirOpcoes: (novas) => { itens = novas.slice(); },
    };
  }

  /** Tabela ordenável por clique no cabeçalho (th[data-ordem="chave"]). */
  function ordenavel(tabela, aoOrdenar) {
    let estado = { chave: null, desc: false };
    $$("th[data-ordem]", tabela).forEach((th) => {
      th.onclick = () => {
        const chave = th.dataset.ordem;
        estado = { chave, desc: estado.chave === chave ? !estado.desc : false };
        $$("th[data-ordem]", tabela).forEach((x) => x.classList.remove("asc", "desc"));
        th.classList.add(estado.desc ? "desc" : "asc");
        aoOrdenar(estado);
      };
    });
    return () => estado;
  }
  function comparar(a, b) {
    const na = typeof a === "number" ? a : normalizar(a), nb = typeof b === "number" ? b : normalizar(b);
    return na < nb ? -1 : na > nb ? 1 : 0;
  }

  function arquivoBase64(arquivo) {
    return new Promise((ok, falha) => {
      const r = new FileReader();
      r.onload = () => ok(String(r.result).split(",")[1] || "");
      r.onerror = () => falha(new Error("Não consegui ler o arquivo."));
      r.readAsDataURL(arquivo);
    });
  }

  return { $, $$, esc, normalizar, hojeBR, api, get, post, montarTopo, atualizarPilula, toast, modal, confirmar, informar,
           acompanhar, retomar, iniciar, mascaraData, dataValida, busca, ordenavel, comparar, arquivoBase64,
           icone, lerOrdem, ordenarPor, gravarOrdem };
})();
