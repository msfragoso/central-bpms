import json
import os
from datetime import date
from nucleo import PASTAS, ErroUsuario, data_br, exigir_confirmacao, gravar_json_dados, ler_json_dados, marcar_uso, rota
ARQ_MEMORIA = 'ultimo_lancamento.json'

def _motor():
    import lancar_tarefas_clickup as m
    m.atualizar_opcoes_parceiro()
    return m

def _memoria():
    dados = ler_json_dados(ARQ_MEMORIA)
    if dados is None:
        try:
            with open(os.path.join(PASTAS['clickup_tasks'], 'ultimo_lancamento.json'), encoding='utf-8') as f:
                dados = json.load(f)
        except (OSError, ValueError):
            dados = {}
    return dados

@rota('GET', '/api/lancar/opcoes')
def opcoes(req):
    m = _motor()
    return (200, {'parceiros': sorted(m.OPCOES_PARCEIRO.keys(), key=lambda s: m.remover_acentos(s).lower()), 'origens': list(m.OPCOES_ORIGEM.keys()), 'periodos': list(m.atualizar_opcoes_periodo().keys()), 'membros': m.carregar_membros_cache(), 'memoria': _memoria()})

@rota('POST', '/api/lancar/membros')
def atualizar_membros(req):
    m = _motor()
    membros = m.listar_membros_workspace()
    m.salvar_membros_cache(membros)
    return (200, {'membros': membros})

@rota('GET', '/api/lancar/faps')
def faps(req):
    m = _motor()
    parceiro = req.query.get('parceiro', '')
    if parceiro not in m.OPCOES_PARCEIRO:
        raise ErroUsuario(f"O parceiro '{parceiro}' não é válido. Selecione um da lista.")
    lista = m.listar_faps_do_parceiro(parceiro, req.query.get('forcar') == '1')
    return (200, {'faps': lista})

@rota('GET', '/api/lancar/periodo')
def periodo(req):
    m = _motor()
    m.atualizar_opcoes_periodo()
    return (200, {'periodo': m.interpretar_periodo(req.query.get('texto', ''))})
PARCEIRO_HC = 'X-Horas Cruzadas'
PARCEIRO_INTERNO = 'X-Interno'
_cache_interno = {}

def _pastas_ou_erro():
    try:
        return _motor().pastas_do_espaco()
    except ErroUsuario:
        raise
    except Exception as e:
        raise ErroUsuario(str(e))

def _lista_interno():
    if 'id' not in _cache_interno:
        pastas, _ = _pastas_ou_erro()
        adm = next((f for f in pastas if f['name'].strip().lower() == 'adm'), None)
        lista = next((l for l in (adm or {}).get('lists', []) if l['name'].strip().lower() == 'particular'), None)
        if not lista:
            raise ErroUsuario("Não achei a lista 'Adm / Particular' no PMO BP-MS para o X-Interno. Sua conta do ClickUp pode não ter acesso a ela.")
        _cache_interno['id'], _cache_interno['nome'] = (str(lista['id']), f"Adm / {lista['name']}")
    return _cache_interno['id']

@rota('GET', '/api/lancar/interno')
def interno(req):
    _lista_interno()
    return (200, {'lista': _cache_interno['nome']})

def _cu_get(caminho):
    import requests
    from clickup_sync.config import CLICKUP_API, CLICKUP_HEADERS
    r = requests.get(f'{CLICKUP_API}{caminho}', headers=CLICKUP_HEADERS, timeout=60)
    if r.status_code != 200:
        raise ErroUsuario(f"ClickUp respondeu {_motor().motivo_clickup(r)} ao listar ({caminho.split('?')[0]}).")
    return r.json()

@rota('GET', '/api/lancar/hc/pastas')
def hc_pastas(req):
    pastas, _ = _pastas_ou_erro()
    saida = [{'id': str(f['id']), 'nome': f['name'], 'listas': [{'id': str(l['id']), 'nome': l['name']} for l in f.get('lists', []) if not l['name'].strip().upper().startswith('Z')]} for f in sorted(pastas, key=lambda x: x['name'].lower())]
    padrao = next((p['id'] for p in saida if 'horas cruzadas' in p['nome'].lower()), '')
    return (200, {'pastas': saida, 'padrao': padrao})

@rota('GET', '/api/lancar/hc/tarefas')
def hc_tarefas(req):
    lista = (req.query.get('lista') or '').strip()
    if not lista.isdigit():
        raise ErroUsuario('Lista inválida.')
    tarefas, pagina = ([], 0)
    while pagina < 10:
        lote = _cu_get(f'/list/{lista}/task?archived=false&subtasks=false&include_closed=false&page={pagina}').get('tasks', [])
        tarefas += [{'id': t['id'], 'nome': t['name'], 'status': (t.get('status') or {}).get('status', '')} for t in lote if not t.get('parent')]
        if len(lote) < 100:
            break
        pagina += 1
    return (200, {'tarefas': sorted(tarefas, key=lambda t: t['nome'].lower())})

@rota('GET', '/api/lancar/hc/pais')
def hc_pais(req):
    _, d = hc_pastas(req)
    pasta = next((p for p in d['pastas'] if p['id'] == d['padrao']), None)
    if not pasta:
        raise ErroUsuario("Não achei a pasta 'Horas Cruzadas' no PMO BP-MS. Sua conta do ClickUp pode não ter acesso a ela.")
    pais = []
    for l in pasta['listas']:

        class _Q:
            query = {'lista': l['id']}
        _, t = hc_tarefas(_Q())
        apelidos = ler_json_dados(ARQ_APELIDOS_HC) or {}
        pais += [{'id': x['id'], 'nome': x['nome'].strip(), 'status': x['status'], 'lista_id': l['id'], 'lista': l['nome'], 'apelido': apelidos.get(x['id']) or nome_curto_parceiro(x['nome'])} for x in t['tarefas']]
    return (200, {'pasta': pasta['nome'], 'pais': sorted(pais, key=lambda x: x['nome'].lower())})
ARQ_APELIDOS_HC = 'hc_apelidos.json'
_PALAVRAS_RAZAO_SOCIAL = {'serv', 'servicos', 'servico', 'comercio', 'com', 'ind', 'industria', 'ltda', 'sa', 's/a', 'me', 'epp', 'eireli', 'transportes', 'transporte', 'seguranca', 'ambientais', 'solucoes', 'franchising', 'franquias', 'de', 'do', 'da', 'dos', 'das', 'e', '&', '-'}

def nome_curto_parceiro(nome_pai):
    import re
    import unicodedata
    m = re.match('^(.*?)\\s*\\(\\d+\\)', nome_pai or '')
    nome = re.sub('\\s*\\(.*?\\)', '', m.group(1) if m else nome_pai or '').strip()
    palavras = nome.split()
    curto = []
    for p in palavras:
        chave = unicodedata.normalize('NFKD', p).encode('ascii', 'ignore').decode().lower().strip('.,')
        if chave in _PALAVRAS_RAZAO_SOCIAL:
            break
        curto.append(p)
    return ' '.join(curto) or (palavras[0] if palavras else '')

def titulo_hc(nome_lista, parceiro, titulo):
    prefixo = f"{(nome_lista or '').strip()} ({(parceiro or '').strip()}) - "
    titulo = (titulo or '').strip()
    return titulo if titulo.lower().startswith(prefixo.lower()) else prefixo + titulo
LIMITE_ANEXOS = 25 * 1024 * 1024

def _ler_anexos(lista):
    import base64
    import re
    saida, total = ([], 0)
    for a in lista or []:
        nome = re.sub('[\\\\/:*?"<>|]', '_', os.path.basename(str(a.get('nome') or 'arquivo')))[:150]
        try:
            dados = base64.b64decode(a.get('conteudo_b64') or '', validate=True)
        except ValueError:
            raise ErroUsuario(f"Anexo '{nome}' inválido. Selecione o arquivo de novo.")
        total += len(dados)
        if total > LIMITE_ANEXOS:
            raise ErroUsuario('Os anexos passam de 25 MB no total. Anexe os maiores direto no ClickUp.')
        if dados:
            saida.append((nome, dados))
    return saida

def _enviar_anexos(task_id, anexos):
    import requests
    from clickup_sync.config import CLICKUP_API, CLICKUP_HEADERS
    ok, falhas = ([], [])
    for nome, dados in anexos:
        try:
            r = requests.post(f'{CLICKUP_API}/task/{task_id}/attachment', headers={'Authorization': CLICKUP_HEADERS['Authorization']}, files={'attachment': (nome, dados)}, timeout=120)
            if r.status_code in (200, 201):
                ok.append(nome)
            else:
                falhas.append(f'{nome} (HTTP {r.status_code})')
        except requests.RequestException as e:
            falhas.append(f'{nome} ({e})')
    avisos = []
    if ok:
        avisos.append(f"📎 {len(ok)} anexo(s) incluído(s): {', '.join(ok)}")
    if falhas:
        avisos.append(f"⚠ Anexo(s) que NÃO entraram (anexe à mão no ClickUp): {', '.join(falhas)}")
    return avisos

@rota('POST', '/api/lancar')
def lancar(req):
    exigir_confirmacao(req)
    m = _motor()
    c = req.corpo
    parceiro = (c.get('parceiro') or '').strip()
    origem = (c.get('origem') or '').strip()
    titulo = titulo_digitado = (c.get('titulo') or '').strip()
    usuario = (c.get('usuario') or '').strip()
    detalhamento = (c.get('detalhamento') or '').strip()
    if not parceiro or not origem or (not titulo) or (not detalhamento) or (not usuario):
        raise ErroUsuario('Parceiro, Origem, Título, Usuário cliente e Detalhamento são obrigatórios!')
    anexos = _ler_anexos(c.get('anexos'))
    if parceiro not in m.OPCOES_PARCEIRO:
        raise ErroUsuario(f"O parceiro '{parceiro}' não é válido. Selecione um da lista!")
    if origem not in m.OPCOES_ORIGEM:
        raise ErroUsuario('Selecione uma origem válida da lista!')
    parent_id = None
    if parceiro == PARCEIRO_HC:
        list_id = str(c.get('hc_lista_id') or '').strip()
        parent_id = str(c.get('hc_pai_id') or '').strip() or None
        if not list_id or not parent_id:
            raise ErroUsuario('Para X-Horas Cruzadas, escolha a pasta, a lista e a tarefa pai.')
        pai = _cu_get(f'/task/{parent_id}')
        apelido = (c.get('hc_apelido') or '').strip() or nome_curto_parceiro(pai.get('name'))
        titulo = titulo_hc((pai.get('list') or {}).get('name'), apelido, titulo)
        apelidos = ler_json_dados(ARQ_APELIDOS_HC) or {}
        if apelidos.get(parent_id) != apelido:
            apelidos[parent_id] = apelido
            gravar_json_dados(ARQ_APELIDOS_HC, apelidos)
    elif parceiro == PARCEIRO_INTERNO:
        list_id = _lista_interno()
    else:
        list_id = str(c.get('fap_id') or '').strip()
    if not list_id:
        raise ErroUsuario('Selecione a FAP em que a demanda deve ser lançada.')
    responsavel_id = c.get('responsavel_id') or None
    data_venc = data_br(c['vencimento'], 'Data de vencimento') if (c.get('vencimento') or '').strip() else None
    if parceiro == PARCEIRO_INTERNO:
        nome_mes = m.gerar_nome_mes_atual(data_venc if data_venc and m.MES_PELA_DATA_VENCIMENTO else None)
        parent_id = m.obter_ou_criar_subtarefa_mensal(list_id, None, nome_mes, m.OPCOES_PARCEIRO.get(parceiro))
    periodo = None
    if (c.get('periodo') or '').strip():
        m.atualizar_opcoes_periodo()
        periodo = m.interpretar_periodo(c['periodo'])
        if not periodo:
            raise ErroUsuario(f"Período '{c['periodo']}' não existe no ClickUp. Selecione uma opção da lista (ex.: 08h-10h).")
        if not data_venc:
            raise ErroUsuario('Período preenchido sem data. Informe a data de vencimento (dia do atendimento) ou apague o período.')
    avisos = []
    task_id = m.criar_demanda_padrao(titulo=titulo, detalhamento=detalhamento, parceiro=parceiro, usuario_cliente=usuario, origem=origem, responsavel_id=responsavel_id, data_vencimento=data_venc, periodo=periodo, list_id=list_id, avisos=avisos, parent_task_id=parent_id)
    if anexos:
        avisos.extend(_enviar_anexos(task_id, anexos))
    gravar_json_dados(ARQ_MEMORIA, {'parceiro': parceiro, 'origem': origem, 'titulo': titulo_digitado, 'usuario': usuario, 'detalhamento': detalhamento})
    marcar_uso('lancar')
    return (200, {'task_id': task_id, 'avisos': avisos, 'periodo': periodo, 'vencimento': data_venc.strftime('%d/%m/%Y') if data_venc else None, 'no_passado': bool(data_venc and data_venc < date.today())})
