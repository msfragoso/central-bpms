import json
import os
import sys
import threading
import time
import traceback
import uuid
from datetime import date, datetime
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PASTA_WEB = os.path.join(RAIZ, 'web')
PASTA_DADOS = os.path.join(RAIZ, 'dados')
CONFIG_PADRAO = {'pasta_motores': 'C:\\sankhya_integracao', 'porta': 8766, 'abrir_navegador': True}

def ler_config():
    cfg = dict(CONFIG_PADRAO)
    try:
        with open(os.path.join(RAIZ, 'config.json'), encoding='utf-8') as f:
            cfg.update(json.load(f))
    except (OSError, ValueError):
        pass
    return cfg
CONFIG = ler_config()
MOTORES = os.path.normpath(os.path.join(RAIZ, CONFIG['pasta_motores']))
PASTAS = {'raiz': MOTORES, 'conferencia': os.path.join(MOTORES, 'conferencia_os'), 'aceite': os.path.join(MOTORES, 'aceite_os'), 'clickup_tasks': os.path.join(MOTORES, 'clickup_tasks')}

def preparar_sys_path():
    for p in (PASTAS['raiz'], PASTAS['conferencia'], PASTAS['aceite'], PASTAS['clickup_tasks']):
        if p not in sys.path:
            sys.path.append(p)
    if os.path.isdir(PASTAS['conferencia']):
        os.chdir(PASTAS['conferencia'])

def para_json(obj):

    def padrao(o):
        if isinstance(o, (date, datetime)):
            return o.strftime('%d/%m/%Y')
        if isinstance(o, set):
            return sorted(o)
        return str(o)
    return json.dumps(obj, ensure_ascii=False, default=padrao)

def dados_arquivo(nome):
    os.makedirs(PASTA_DADOS, exist_ok=True)
    return os.path.join(PASTA_DADOS, nome)

def ler_json_dados(nome, padrao=None):
    try:
        with open(dados_arquivo(nome), encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return padrao

def gravar_json_dados(nome, valor):
    with open(dados_arquivo(nome), 'w', encoding='utf-8') as f:
        json.dump(valor, f, ensure_ascii=False, indent=2)

def marcar_uso(chave):
    usos = ler_json_dados('ultimo_uso.json', {}) or {}
    usos[chave] = datetime.now().strftime('%d/%m %H:%M')
    gravar_json_dados('ultimo_uso.json', usos)

class Cancelada(Exception):
    pass

class Tarefa:

    def __init__(self, tipo, titulo):
        self.id = uuid.uuid4().hex[:12]
        self.tipo = tipo
        self.titulo = titulo
        self.estado = 'rodando'
        self.inicio = datetime.now()
        self.fim = None
        self.mensagem = ''
        self.resultado = None
        self.arquivos = []
        self._linhas = []
        self._parcial = ''
        self._lock = threading.Lock()
        self._pergunta = None
        self._evento = threading.Event()
        self._resposta = None

    def escrever(self, texto):
        if not texto:
            return
        with self._lock:
            texto = self._parcial + str(texto)
            partes = texto.split('\n')
            self._parcial = partes.pop()
            self._linhas.extend(partes)

    def log(self, msg):
        self.escrever(str(msg) + '\n')

    def linhas_desde(self, n):
        with self._lock:
            linhas = self._linhas[n:]
            total = len(self._linhas)
            if self._parcial and self.estado not in ('rodando', 'aguardando'):
                linhas = linhas + [self._parcial]
        return (linhas, total)

    def perguntar(self, titulo, texto, opcoes):
        with self._lock:
            self._pergunta = {'id': uuid.uuid4().hex[:8], 'titulo': titulo, 'texto': texto, 'opcoes': opcoes}
            self._evento.clear()
            self.estado = 'aguardando'
        self._evento.wait()
        with self._lock:
            self._pergunta = None
            self.estado = 'rodando'
            return self._resposta

    def responder(self, pergunta_id, valor):
        with self._lock:
            if not self._pergunta or self._pergunta['id'] != pergunta_id:
                return False
            self._resposta = valor
        self._evento.set()
        return True

    def adicionar_arquivo(self, rotulo, caminho):
        if caminho:
            caminho = os.path.abspath(caminho)
            if os.path.isfile(caminho):
                self.arquivos.append((rotulo, caminho))

    def estado_json(self, desde=0):
        linhas, total = self.linhas_desde(desde)
        return {'id': self.id, 'tipo': self.tipo, 'titulo': self.titulo, 'estado': self.estado, 'inicio': self.inicio.strftime('%d/%m/%Y %H:%M:%S'), 'fim': self.fim.strftime('%d/%m/%Y %H:%M:%S') if self.fim else None, 'mensagem': self.mensagem, 'resultado': self.resultado, 'linhas': linhas, 'total_linhas': total, 'pergunta': self._pergunta, 'arquivos': [{'indice': i, 'rotulo': r, 'nome': os.path.basename(c)} for i, (r, c) in enumerate(self.arquivos)]}

class Ocupado(Exception):

    def __init__(self, tarefa):
        super().__init__(f'Não dá para rodar agora junto com: {tarefa.titulo} (espere terminar)')
        self.tarefa = tarefa
GRUPOS_EXCLUSIVOS = {'experience': {'sync', 'sync_sem_os_excluir', 'sync_incluir', 'aceite_enviar'}, 'clickup_escrita': {'borracha', 'permissoes', 'conferencia'}, 'email': {'agenda_teste', 'agenda_enviar'}}
MAX_SIMULTANEOS = 3
_tarefa_da_thread = threading.local()
_thread_init_original = threading.Thread.__init__
_thread_run_original = threading.Thread.run

def _thread_init(self, *a, **k):
    _thread_init_original(self, *a, **k)
    self._bpms_tarefa = getattr(_tarefa_da_thread, 't', None)

def _thread_run(self):
    if getattr(self, '_bpms_tarefa', None) is not None:
        _tarefa_da_thread.t = self._bpms_tarefa
    _thread_run_original(self)
threading.Thread.__init__ = _thread_init
threading.Thread.run = _thread_run

def _grupos(tipo):
    return {g for g, tipos in GRUPOS_EXCLUSIVOS.items() if tipo in tipos}

class Gerente:

    def __init__(self):
        self.tarefas = {}
        self._lock = threading.Lock()

    @property
    def ativas(self):
        return [t for t in list(self.tarefas.values()) if t.estado in ('rodando', 'aguardando')]

    @property
    def ativa(self):
        lista = self.ativas
        return lista[-1] if lista else None

    def iniciar(self, tipo, titulo, funcao, pasta=None):
        with self._lock:
            ativas = self.ativas
            for a in ativas:
                if a.tipo == tipo or _grupos(a.tipo) & _grupos(tipo):
                    raise Ocupado(a)
            if len(ativas) >= MAX_SIMULTANEOS:
                raise Ocupado(ativas[0])
            t = Tarefa(tipo, titulo)
            self.tarefas[t.id] = t
            for antigo in list(self.tarefas)[:-30]:
                if self.tarefas[antigo].estado not in ('rodando', 'aguardando'):
                    self.tarefas.pop(antigo, None)

        def rodar():
            _tarefa_da_thread.t = t
            try:
                retorno = funcao(t) or {}
                t.mensagem = retorno.get('mensagem', 'Concluído.')
                t.resultado = retorno.get('resultado')
                t.estado = retorno.get('estado', 'concluida')
            except Cancelada as e:
                t.log(f'\n⏹ CANCELADO: {e}')
                t.mensagem = str(e) or 'Cancelado pelo usuário.'
                t.estado = 'cancelada'
            except BaseException as e:
                t.log(f'\n❌ ERRO: {e}')
                t.log(traceback.format_exc())
                t.mensagem = str(e) or e.__class__.__name__
                t.estado = 'erro'
            finally:
                t.fim = datetime.now()
                _tarefa_da_thread.t = None
        threading.Thread(target=rodar, daemon=True, name=f'tarefa-{t.id}').start()
        return t

    def obter(self, tarefa_id):
        return self.tarefas.get(tarefa_id)
GERENTE = Gerente()

class RoteadorSaida:

    def __init__(self, original):
        self.original = original
        self.encoding = 'utf-8'

    def write(self, texto):
        t = getattr(_tarefa_da_thread, 't', None) or GERENTE.ativa
        if t is not None and t.estado in ('rodando', 'aguardando'):
            t.escrever(texto)
        if self.original is not None:
            try:
                self.original.write(texto)
            except Exception:
                pass
        return len(texto) if texto else 0

    def flush(self):
        if self.original is not None:
            try:
                self.original.flush()
            except Exception:
                pass

    def isatty(self):
        return False

def instalar_log_de_erros():
    import threading as _th
    import traceback as _tb
    arq = open(dados_arquivo('servico.log'), 'a', encoding='utf-8', buffering=1)
    arq.write(f'\n===== serviço iniciado em {datetime.now():%d/%m/%Y %H:%M:%S} =====\n')
    if sys.stderr is None:
        sys.stderr = arq

    def _registrar(tipo, valor, tb, onde='principal'):
        arq.write(f'[{datetime.now():%d/%m %H:%M:%S}] erro não tratado ({onde}):\n')
        arq.write(''.join(_tb.format_exception(tipo, valor, tb)))
    sys.excepthook = _registrar
    _th.excepthook = lambda a: _registrar(a.exc_type, a.exc_value, a.exc_traceback, f'thread {a.thread.name}')
    import atexit
    atexit.register(lambda: arq.write(f'[{datetime.now():%d/%m %H:%M:%S}] serviço encerrado\n'))

def instalar_roteador():
    if not isinstance(sys.stdout, RoteadorSaida):
        sys.stdout = RoteadorSaida(sys.stdout)
    if not isinstance(sys.stderr, RoteadorSaida):
        sys.stderr = RoteadorSaida(sys.stderr)
ROTAS = {}

class Requisicao:

    def __init__(self, metodo, caminho, query, corpo):
        self.metodo = metodo
        self.caminho = caminho
        self.query = query
        self.corpo = corpo
        self.partes = []

class ErroUsuario(Exception):
    pass

def rota(metodo, caminho):

    def registrar(f):
        ROTAS[metodo, caminho] = f
        return f
    return registrar

def resolver_rota(metodo, caminho):
    f = ROTAS.get((metodo, caminho))
    if f:
        return (f, [])
    pedacos = caminho.strip('/').split('/')
    for (m, modelo), f in ROTAS.items():
        if m != metodo:
            continue
        mp = modelo.strip('/').split('/')
        if len(mp) != len(pedacos):
            continue
        vars_ = []
        for a, b in zip(mp, pedacos):
            if a == '*':
                vars_.append(b)
            elif a != b:
                break
        else:
            return (f, vars_)
    return (None, [])

def data_br(texto, campo='Data'):
    try:
        return datetime.strptime((texto or '').strip().replace('-', '/'), '%d/%m/%Y').date()
    except ValueError:
        raise ErroUsuario(f'{campo} inválida. Use DD/MM/AAAA.')

def periodo_br(de, ate):
    a, b = (data_br(de, 'Data inicial'), data_br(ate, 'Data final'))
    if a > b:
        raise ErroUsuario('A data inicial é maior que a final.')
    return (a, b)

def exigir_confirmacao(req):
    if req.corpo.get('confirmar') is not True:
        raise ErroUsuario('Ação não confirmada.')

def agora_txt():
    return time.strftime('%d/%m/%Y %H:%M:%S')
