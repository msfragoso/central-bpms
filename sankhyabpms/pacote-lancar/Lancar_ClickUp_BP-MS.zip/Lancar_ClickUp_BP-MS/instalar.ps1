﻿# Instalador do "Lançar ClickUp BP-MS" (23/10/2026).
# Faz tudo sozinho: Python (se faltar), bibliotecas, cópia para pasta fixa, atalhos e token.
$ErrorActionPreference = "Stop"
$Host.UI.RawUI.WindowTitle = "Instalando o Lançar ClickUp BP-MS"
$origem  = Split-Path -Parent $MyInvocation.MyCommand.Path
$destino = Join-Path $env:LOCALAPPDATA "Lancar_ClickUp_BP-MS"
function Passo($n, $t) { Write-Host ""; Write-Host "[$n/6] $t" -ForegroundColor Cyan }
function Falha($t) {
    Write-Host ""; Write-Host "NÃO DEU CERTO: $t" -ForegroundColor Red
    Write-Host "Tire um print desta janela e envie para quem te mandou o instalador."
    Read-Host "Aperte Enter para fechar"; exit 1
}

function Achar-Python {
    $cands = @()
    foreach ($c in @("py", "python")) {
        try {
            $exe = & $c -3 -c "import sys; print(sys.executable)" 2>$null
            if (-not $exe) { $exe = & $c -c "import sys; print(sys.executable)" 2>$null }
            if ($exe -and (Test-Path $exe)) { $cands += $exe }
        } catch {}
    }
    $cands += Get-ChildItem "$env:LOCALAPPDATA\Programs\Python\Python3*\python.exe" -ErrorAction SilentlyContinue | ForEach-Object FullName
    $cands += Get-ChildItem "$env:ProgramFiles\Python3*\python.exe" -ErrorAction SilentlyContinue | ForEach-Object FullName
    foreach ($p in $cands) {
        try {
            $ok = & $p -c "import sys, tkinter; print(sys.version_info >= (3, 9))" 2>$null
            if ($ok -eq "True") { return $p }
        } catch {}
    }
    return $null
}

Write-Host "=== Lançar ClickUp BP-MS — instalação ===" -ForegroundColor Green
Write-Host "Pasta do programa: $destino"

Passo 1 "Procurando o Python..."
$py = Achar-Python
if (-not $py) {
    Write-Host "Python não encontrado. Instalando (só para o seu usuário, sem pedir administrador)..."
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        try { & winget install -e --id Python.Python.3.12 --scope user --silent --accept-package-agreements --accept-source-agreements | Out-Host } catch {}
        $py = Achar-Python
    }
    if (-not $py) {
        $url = "https://www.python.org/ftp/python/3.12.7/python-3.12.7-amd64.exe"
        $tmp = Join-Path $env:TEMP "python-3.12.7-amd64.exe"
        Write-Host "Baixando o Python do site oficial (python.org)..."
        try {
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing
        } catch { Falha "não consegui baixar o Python ($url). Verifique a internet." }
        Write-Host "Instalando o Python (leva 1-2 minutos)..."
        Start-Process -FilePath $tmp -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_pip=1" -Wait
        $py = Achar-Python
    }
    if (-not $py) { Falha "o Python não ficou instalado. Instale pelo site python.org e rode o instalador de novo." }
}
$pyw = Join-Path (Split-Path $py) "pythonw.exe"
if (-not (Test-Path $pyw)) { $pyw = $py }
Write-Host "Python: $py"

Passo 2 "Instalando as bibliotecas (requests, keyring)..."
& $py -m pip install --user --upgrade --disable-pip-version-check -q requests keyring | Out-Host
if ($LASTEXITCODE -ne 0) { Falha "o pip não instalou as bibliotecas. Verifique a internet ou o proxy da empresa." }

Passo 3 "Copiando o programa..."
Get-CimInstance Win32_Process -Filter "Name like 'python%'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like "*Lancar_ClickUp_BP-MS*servidor.py*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
New-Item -ItemType Directory -Force -Path $destino | Out-Null
foreach ($item in @("central", "motores", "configurar_token.py", "configurar_token.vbs", "Abrir_Lancar_ClickUp.vbs", "Configurar_Token_ClickUp.bat", "Desinstalar.bat", "desinstalar.ps1", "LEIA-ME.txt")) {
    Copy-Item -Path (Join-Path $origem $item) -Destination $destino -Recurse -Force
}
# 23/10/2026: UTF-16, para usuario com acento no nome (ex.: C:\Users\USUÁRIO)
Set-Content -Path (Join-Path $destino "python.txt") -Value $pyw -Encoding Unicode

Passo 4 "Criando os atalhos (Área de Trabalho e Menu Iniciar)..."
$sh = New-Object -ComObject WScript.Shell
$icone = Join-Path $destino "central\web\assets\icones\central.ico"
$menu = Join-Path ([Environment]::GetFolderPath("Programs")) "Lançar ClickUp BP-MS"
New-Item -ItemType Directory -Force -Path $menu | Out-Null
$atalhos = @(
    @{ Caminho = Join-Path ([Environment]::GetFolderPath("Desktop")) "Lançar ClickUp BP-MS.lnk"; Alvo = "Abrir_Lancar_ClickUp.vbs" },
    @{ Caminho = Join-Path $menu "Lançar ClickUp BP-MS.lnk"; Alvo = "Abrir_Lancar_ClickUp.vbs" },
    @{ Caminho = Join-Path $menu "Configurar token do ClickUp.lnk"; Alvo = "configurar_token.vbs" },
    @{ Caminho = Join-Path $menu "Desinstalar.lnk"; Alvo = "Desinstalar.bat" }
)
foreach ($a in $atalhos) {
    $lnk = $sh.CreateShortcut($a.Caminho)
    if ($a.Alvo -like "*.vbs") { $lnk.TargetPath = "$env:WINDIR\System32\wscript.exe"; $lnk.Arguments = "`"$(Join-Path $destino $a.Alvo)`"" }
    else { $lnk.TargetPath = Join-Path $destino $a.Alvo }
    $lnk.WorkingDirectory = $destino
    $lnk.IconLocation = $icone
    $lnk.Save()
}

Passo 5 "Conferindo o token do ClickUp..."
$tem = & $py -c "import keyring; print(bool(keyring.get_password('sankhya_experience_sync', 'CLICKUP_TOKEN')))" 2>$null
if ($tem -ne "True") {
    Write-Host "Falta o seu token pessoal do ClickUp. Vai abrir uma janela para colar."
    Write-Host "Onde pegar: ClickUp > seu avatar > Settings > Apps (ClickUp API) > API Token > Generate > Copy (começa com pk_)."
    Start-Process -FilePath $pyw -ArgumentList "`"$(Join-Path $destino 'configurar_token.py')`"" -WorkingDirectory $destino -Wait
    $tem = & $py -c "import keyring; print(bool(keyring.get_password('sankhya_experience_sync', 'CLICKUP_TOKEN')))" 2>$null
    if ($tem -ne "True") { Write-Host "Token não gravado. Depois use 'Configurar token do ClickUp' no Menu Iniciar." -ForegroundColor Yellow }
} else { Write-Host "Token já configurado neste computador." }

Passo 6 "Pronto!"
Write-Host "Use o atalho 'Lançar ClickUp BP-MS' na Área de Trabalho." -ForegroundColor Green
Start-Process -FilePath "$env:WINDIR\System32\wscript.exe" -ArgumentList "`"$(Join-Path $destino 'Abrir_Lancar_ClickUp.vbs')`""
Start-Sleep -Seconds 4
