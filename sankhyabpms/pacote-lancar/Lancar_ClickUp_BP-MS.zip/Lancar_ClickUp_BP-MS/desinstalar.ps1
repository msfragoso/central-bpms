﻿# Remove o Lançar ClickUp BP-MS (programa e atalhos). O token continua no cofre do Windows.
$destino = Join-Path $env:LOCALAPPDATA "Lancar_ClickUp_BP-MS"
$r = Read-Host "Remover o Lançar ClickUp BP-MS deste computador? (S/N)"
if ($r -notmatch '^[sS]') { exit }
# inicio-parar-servico
$porta = 8766
$servicos = @(Get-CimInstance Win32_Process -Filter "Name like 'python%'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like "*servidor.py*" })
$parar = @($servicos | Where-Object { $_.CommandLine -like "*Lancar_ClickUp_BP-MS*" } | ForEach-Object { $_.ProcessId })
$donos = @(Get-NetTCPConnection -LocalPort $porta -State Listen -ErrorAction SilentlyContinue | ForEach-Object { $_.OwningProcess })
if ($donos.Count -gt 0) {
    $ehCentral = $false
    try { $ehCentral = (Invoke-WebRequest "http://127.0.0.1:$porta/conferencia.html" -UseBasicParsing -TimeoutSec 5).StatusCode -eq 200 } catch {}
    if (-not $ehCentral) {
        $parar += @($servicos | Where-Object { $donos -contains $_.ProcessId } | ForEach-Object { $_.ProcessId })
    }
}
if ($parar.Count -gt 0) {
    $parar | Select-Object -Unique | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Seconds 2
}
# fim-parar-servico
Remove-Item (Join-Path ([Environment]::GetFolderPath("Desktop")) "Lançar ClickUp BP-MS.lnk") -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath("Programs")) "Lançar ClickUp BP-MS") -Recurse -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1
Remove-Item $destino -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Removido." -ForegroundColor Green
Start-Sleep -Seconds 2
