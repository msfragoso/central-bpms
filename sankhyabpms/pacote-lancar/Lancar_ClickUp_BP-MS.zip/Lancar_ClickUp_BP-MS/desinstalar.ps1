﻿# Remove o Lançar ClickUp BP-MS (programa e atalhos). O token continua no cofre do Windows.
$destino = Join-Path $env:LOCALAPPDATA "Lancar_ClickUp_BP-MS"
$r = Read-Host "Remover o Lançar ClickUp BP-MS deste computador? (S/N)"
if ($r -notmatch '^[sS]') { exit }
Get-CimInstance Win32_Process -Filter "Name like 'python%'" -ErrorAction SilentlyContinue |
    Where-Object { $_.CommandLine -like "*Lancar_ClickUp_BP-MS*servidor.py*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Remove-Item (Join-Path ([Environment]::GetFolderPath("Desktop")) "Lançar ClickUp BP-MS.lnk") -ErrorAction SilentlyContinue
Remove-Item (Join-Path ([Environment]::GetFolderPath("Programs")) "Lançar ClickUp BP-MS") -Recurse -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1
Remove-Item $destino -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "Removido." -ForegroundColor Green
Start-Sleep -Seconds 2
